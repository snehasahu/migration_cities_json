<?php

declare(strict_types=1);

namespace Drupal\cities_properties;

use Drupal\Core\Config\Entity\ConfigEntityListBuilder;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Url;

/**
 * Defines a class to build a listing of cities properties type entities.
 *
 * @see \Drupal\cities_properties\Entity\CitiesPropertiesType
 */
final class CitiesPropertiesTypeListBuilder extends ConfigEntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader(): array {
    $header['label'] = $this->t('Label');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity): array {
    $row['label'] = $entity->label();
    return $row + parent::buildRow($entity);
  }

  /**
   * {@inheritdoc}
   */
  public function render(): array {
    $build = parent::render();

    $build['table']['#empty'] = $this->t(
      'No cities properties types available. <a href=":link">Add cities properties type</a>.',
      [':link' => Url::fromRoute('entity.cities_properties_type.add_form')->toString()],
    );

    return $build;
  }

}
