<?php

declare(strict_types=1);

namespace Drupal\cities_properties\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBundleBase;

/**
 * Defines the Cities properties type configuration entity.
 *
 * @ConfigEntityType(
 *   id = "cities_properties_type",
 *   label = @Translation("Cities properties type"),
 *   label_collection = @Translation("Cities properties types"),
 *   label_singular = @Translation("cities properties type"),
 *   label_plural = @Translation("cities propertiess types"),
 *   label_count = @PluralTranslation(
 *     singular = "@count cities propertiess type",
 *     plural = "@count cities propertiess types",
 *   ),
 *   handlers = {
 *     "form" = {
 *       "add" = "Drupal\cities_properties\Form\CitiesPropertiesTypeForm",
 *       "edit" = "Drupal\cities_properties\Form\CitiesPropertiesTypeForm",
 *       "delete" = "Drupal\Core\Entity\EntityDeleteForm",
 *     },
 *     "list_builder" = "Drupal\cities_properties\CitiesPropertiesTypeListBuilder",
 *     "route_provider" = {
 *       "html" = "Drupal\Core\Entity\Routing\AdminHtmlRouteProvider",
 *     },
 *   },
 *   admin_permission = "administer cities_properties types",
 *   bundle_of = "cities_properties",
 *   config_prefix = "cities_properties_type",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid",
 *   },
 *   links = {
 *     "add-form" = "/admin/structure/cities_properties_types/add",
 *     "edit-form" = "/admin/structure/cities_properties_types/manage/{cities_properties_type}",
 *     "delete-form" = "/admin/structure/cities_properties_types/manage/{cities_properties_type}/delete",
 *     "collection" = "/admin/structure/cities_properties_types",
 *   },
 *   config_export = {
 *     "id",
 *     "label",
 *     "uuid",
 *   },
 * )
 */
final class CitiesPropertiesType extends ConfigEntityBundleBase {

  /**
   * The machine name of this cities properties type.
   */
  protected string $id;

  /**
   * The human-readable name of the cities properties type.
   */
  protected string $label;

}
