<?php

declare(strict_types=1);

namespace Drupal\cities_properties;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\user\EntityOwnerInterface;

/**
 * Provides an interface defining a cities properties entity type.
 */
interface CitiesPropertiesInterface extends ContentEntityInterface, EntityOwnerInterface, EntityChangedInterface {

}
